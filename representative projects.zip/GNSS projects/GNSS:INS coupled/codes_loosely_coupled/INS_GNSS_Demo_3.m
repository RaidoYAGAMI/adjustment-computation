%INS_GNSS
%SCRIPT Loosely coupled INS/GNSS:
%   Tactical-grade IMU
%
% Software for use with "Principles of GNSS, Inertial, and Multisensor
% Integrated Navigation Systems," Second Edition.
%

% Original Copyright 2012, Paul Groves
% License: BSD; see license.txt for details

% Constants 
deg_to_rad = 0.01745329252;
rad_to_deg = 1/deg_to_rad;
micro_g_to_meters_per_second_squared = 9.80665E-6;

% CONFIGURATION
% Input truth motion profile filename  
input_profile_name_s = '/Users/zhangyushan/Desktop/zys/��ϵ���/����ϳ���/loose_k.txt';    % loose_s.txt GINS��̬����Ͻ�����
input_profile_name_g = '/Users/zhangyushan/Desktop/zys/��ϵ���/����ϳ���/gnss_k.txt';     % gnss_s.txt GNSS��̬������(λ�ã��ٶ�)
input_profile_name_i = '/Users/zhangyushan/Desktop/zys/��ϵ���/����ϳ���/32dt.txt';  % jtsy1.txt ��̬�ߵ�ԭʼ����

% input_profile_name_s = 'loose_k.txt';    % loose_s.txt GINS����Ͻ����� 
% input_profile_name_g = 'gnss_k.txt';     % gnss_s.txt GNSS������(λ�ã��ٶ�)
% input_profile_name_i = '32dt.txt';  % jtsy1.txt �ߵ�ԭʼ����


% Output motion profile and error filenames
output_profile_name = 'INS_GNSS_Profile.csv';
output_errors_name = 'INS_GNSS_Errors.csv';

% Attitude initialization error (deg, converted to rad; @N,E,D)
initialization_errors.delta_eul_nb_n = [-0.05;0.04;1]*deg_to_rad; % rad

% Initial attitude uncertainty per axis (deg, converted to rad)
LC_KF_config.init_att_unc = deg2rad(1);
% Initial velocity uncertainty per axis (m/s)
LC_KF_config.init_vel_unc = 0.1;
% Initial position uncertainty per axis (m)
LC_KF_config.init_pos_unc = 10;
% Initial accelerometer bias uncertainty per instrument (micro-g, converted
% to m/s^2)
LC_KF_config.init_b_a_unc = 1000 * micro_g_to_meters_per_second_squared;
% Initial gyro bias uncertainty per instrument (deg/hour, converted to rad/sec)
LC_KF_config.init_b_g_unc = 10 * deg_to_rad / 3600;

% Gyro noise PSD (deg^2 per hour, converted to rad^2/s)                
LC_KF_config.gyro_noise_PSD = (0.02 * deg_to_rad / 60)^2;
% Accelerometer noise PSD (micro-g^2 per Hz, converted to m^2 s^-3)                
LC_KF_config.accel_noise_PSD = (200 *...
    micro_g_to_meters_per_second_squared)^2;
% Accelerometer bias random walk PSD (m^2 s^-5)
LC_KF_config.accel_bias_PSD = 1.0E-7;
% Gyro bias random walk PSD (rad^2 s^-3)
LC_KF_config.gyro_bias_PSD = 2.0E-12;

% Position measurement noise SD per axis (m)
LC_KF_config.pos_meas_SD = 2.5;
% Velocity measurement noise SD per axis (m/s)
LC_KF_config.vel_meas_SD = 0.1;

% Seeding of the random number generator for reproducability. Change 
% this value for a different random number sequence (may not work in Octave).
% RandStream.setDefaultStream(RandStream('mt19937ar','seed',1));

% Begins

% Input truth motion profile from .csv format file (GINS����Ͻ�����)
% Read_profile�����ѽ��Ƕȵ�λתΪrad
[in_profile,~,ok_s] = Read_profile(input_profile_name_s);
% End script if there is a problem with the file
if ~ok_s
    return;
end %if
% Input GNSS results : position and velocity 
GNSS_r_v = importdata(input_profile_name_g);
% Input IMU data
IMU_meas = importdata(input_profile_name_i);
% �ߵ���ϵ���������� �ܹؼ���֮ǰ������Ϊȱ����һ�������½��������
IMU_meas(:,2:4) = [IMU_meas(:,3),IMU_meas(:,2),-IMU_meas(:,4)];
IMU_meas(:,5:7) = [IMU_meas(:,6),IMU_meas(:,5),-IMU_meas(:,7)];
% IMU_meas1(:,1)=IMU_meas(:,1);
% IMU_meas1(:,2)=IMU_meas(:,3);
% IMU_meas1(:,3)=IMU_meas(:,2);
% IMU_meas1(:,4)=-IMU_meas(:,4);
% IMU_meas1(:,5)=IMU_meas(:,5);
% IMU_meas1(:,6)=IMU_meas(:,6);
% IMU_meas1(:,7)=-IMU_meas(:,7);

no_epochs=size(IMU_meas,1);

% Loosely coupled ECEF Inertial navigation and GNSS integrated navigation
[out_profile,out_errors,out_IMU_bias_est,out_clock,out_KF_SD] =...
    Loosely_coupled_INS_GNSS(in_profile,no_epochs,initialization_errors...
    ,GNSS_r_v,LC_KF_config,IMU_meas);

% Plot the input motion profile and the errors (may not work in Octave).
close all;
% in_profile(:,2:3) = in_profile(:,2:3) * (1/deg_to_rad);
% in_profile(:,8:10) = in_profile(:,8:10) * (1/deg_to_rad);
%Plot_profile(in_profile); % GINS�����
% out_profile(:,2:3) = out_profile(:,2:3) * (1/deg_to_rad);
% out_profile(:,8:10) = out_profile(:,8:10) * (1/deg_to_rad);
Plot_profile(out_profile); % �Ա������
% out_errors(:,8:10) = out_errors(:,8:10) * (1/deg_to_rad);
%Plot_errors(out_errors); % ������������

% Write output profile and errors file
Write_profile(output_profile_name,out_profile);
%Write_errors(output_errors_name,out_errors);

% Ends