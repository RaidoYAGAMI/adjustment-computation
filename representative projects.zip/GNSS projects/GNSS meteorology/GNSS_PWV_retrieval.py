#==========================================================
 SaturationWaterVaporPressure/MeteoElement2PWV
#    ParameterName        ID        Units 
#    Geopotential         129       m**2 s**-2
#    Relative humidity    157       %
#    Specific humidity    133       Kg Kg**-1
#    Temperature          130       K
#    // For Water vapor come from ECMWF Reanalysis
#    Skin Temperature              235             K
#    Surface Pressure              134             Pa
#    Total column water vapour     137             kg m**-2
#    Orography                     129             m**2 s**-2
#
import os, sys
import math
import traceback
import time

##==============Input Parameters=================
ecmwf_grib="/scratch/glfeng/sichuan_area/312/20211108_1h.grib"
ztd_cfg="/scratch/glfeng/sichuan_area/312/cf_net"
interpsoft="/project/glfeng/GNSS/egm/interp_1min"
##===============================================
##==============Constant Parameters==============
VERBOSE=1
rad2deg=180.0/math.pi
deg2rad=math.pi/180.0
earth_r=6378137.0  ## WGS84 in meters
#earth_g=9.80665  ## Earth's gravitational acceleration, g(=9.80665 m s-2)
##===============================================


## Input  zwd[mm] Tm[K]
## Output pwv[mm]
## 1N=1kg·m/s^2,1J=N·m
def zwd2pwv(zwd,Tm):
	rhow=999.97   # Dichte von Wasser kg/m**3
	Rv=461.51     # specific gas constant for water vapor J/(K*kg)
	k3=3.739*1.e5 # atmospheric refraction constants +-1200 K**2/mbar=K**2/hPa
	k2pai=22.1    # atmospheric refraction constants +-2.2  K/mbar=K/hPa
	rhowRv=rhow*Rv
	pfak=100*1.e6/(rhowRv*(k2pai+k3/Tm))
	pwv=pfak*zwd
	return pwv


## Input (x,y,z),scale when coordinates in meters, scale equal to 1.0
## Output (b,l) in degrees, ellipsoid height in meters
def xyzblh(x,y,z,scale):
	## ellipsoid WGS84 
	a=6378137.e0
	b=298.257223563e0
	## to meters
	xp=x*scale*1.e0
	yp=y*scale*1.e0
	zp=z*scale*1.e0
	
	if b <= 6000000.e0:  b=a-a/b
	e2=(a*a-b*b)/(a*a)
	s=math.sqrt(xp*xp+yp*yp)
	rl=math.atan2(yp,xp)
	
	if rl < 0.e0:  rl=2.e0*math.pi+rl

	zps=zp/s
	rh=math.sqrt(xp*xp+yp*yp+zp*zp)-a
	rb=math.atan(zps/(1.e0-e2*a/(a+rh)))
	
	i=1
	while i <= 10:   
		n=a/math.sqrt(1.e0-e2*math.sin(rb)**2)
		hp=rh
		rbi=rb
		rh=s/math.cos(rb)-n
		rb=math.atan(zps/(1.e0-e2*n/(n+rh)))
		rbd=abs(rbi-rb)
		rhd=abs(hp-rh)
		if rbd <= 1.e-11 and rhd <= 1.e-5: break
	
	#print(' %15.10f %15.10f %11.4f ' % (rb*rad2deg,rl*rad2deg,rh))
	return rb*rad2deg,rl*rad2deg,rh


## 根据纬度以及大地高求出某点的重力加速度
## 输入 纬度（弧度制）+大地高
## 输出 重力加速度
def cal_gravity(B,H):
	sin2=math.sin(B)*math.sin(B)
	g1=9.7803267715*(1.0+0.0052790414*sin2+0.0000232718*sin2*sin2)
	g2=(-0.000003087691089+0.000000004397731*sin2)*H
	g3=0.000000000000721*H*H
	g=g1+g2+g3
	return g


## 根据测站列表时间生成INPUT.DAT文件用于后续计算
## Input  测站列表sitelist/年year/年积日doy
## Output None
## Format ""
def generate_blh(sitelist,year,doy):
	f_input_geoid_undulation=open("INPUT.DAT","a")
	cdoy=str(doy).zfill(3)
	target_cfg=ztd_cfg.replace("REPLACE",str(year)+cdoy)
	print(' %s %s' % (str(year)+cdoy,target_cfg))
	with open(sitelist,"r") as fr:
		for line in fr:
			if len(line) == 6 and line[0] == " ":
				site=line[1:5].upper()
				v_list=os.popen("grep "+site+"_POS "+target_cfg).read().split()
				x=float(v_list[1])
				y=float(v_list[2])
				z=float(v_list[3])
				b,l,h=xyzblh(x,y,z,1.0)
				f_input_geoid_undulation.write(' %s %s%16.10f%16.10f%13.5f\n' % (str(year)+cdoy,site,b,l,h))
	f_input_geoid_undulation.close()


## Input  解码的文件名
## Output 格网点数据ecmwfdata1-4,目标点(lat,lon)
## Format ""
## 不使用split()，是为了及时发现解码存在的问题
def read_decoded_file(file):
	ecmwfdata1={}
	ecmwfdata2={}
	ecmwfdata3={}
	ecmwfdata4={}
	lat=[]
	lon=[]
	with open(file,'r') as fr:
		for line in fr:
			if line[0:4] == "ecmf":
				hr = int(line[24:28])
				pr = int(line[36:41])
				id = int(line[48:55])
				v_list = line[58:].split()
				if hr not in ecmwfdata1.keys():
					ecmwfdata1[hr]={}
					ecmwfdata1[hr][pr]={}
					ecmwfdata1[hr][pr][id]=float(v_list[0])
					ecmwfdata2[hr]={}
					ecmwfdata2[hr][pr]={}
					ecmwfdata2[hr][pr][id]=float(v_list[1])
					ecmwfdata3[hr]={}
					ecmwfdata3[hr][pr]={}
					ecmwfdata3[hr][pr][id]=float(v_list[2])
					ecmwfdata4[hr]={}
					ecmwfdata4[hr][pr]={}
					ecmwfdata4[hr][pr][id]=float(v_list[3])
				else:
					if pr not in ecmwfdata1[hr].keys():
						ecmwfdata1[hr][pr]={}
						ecmwfdata1[hr][pr][id]=float(v_list[0])
						ecmwfdata2[hr][pr]={}
						ecmwfdata2[hr][pr][id]=float(v_list[1])
						ecmwfdata3[hr][pr]={}
						ecmwfdata3[hr][pr][id]=float(v_list[2])
						ecmwfdata4[hr][pr]={}
						ecmwfdata4[hr][pr][id]=float(v_list[3])
					else:
						ecmwfdata1[hr][pr][id]=float(v_list[0])
						ecmwfdata2[hr][pr][id]=float(v_list[1])
						ecmwfdata3[hr][pr][id]=float(v_list[2])
						ecmwfdata4[hr][pr][id]=float(v_list[3])
			elif line[4:11] == "- index":
				strline=line[6:].replace("="," ").split()
				lat.append(float(strline[3]))
				lon.append(float(strline[5]))
			else:
				a = 0
	return ecmwfdata1,ecmwfdata2,ecmwfdata3,ecmwfdata4,lat,lon


## 根据Saastamoinen模型以及从ecmwf得到的气象数据，算出ZHD
## Input  测站气压SitePressure
##        测站纬度（弧度制）lat
##        测站大地高ell_height
## Output 测站每个小时的ZHD
def ZHDFromSaastamoinen(SitePressure,lat,ell_height):
	ZHD={}
	for hr in SitePressure.keys():
		zf=1-2.66*1.e-3*math.cos(2*lat)-2.8*1.e-7*ell_height
		perzhd=2.2768*1.e-5*SitePressure[hr]*100/zf
		ZHD[hr]=perzhd
	return ZHD


## 根据水平内插后的数据，测站气压温度求得每个时间间隔的ZWD
## Input  水平内插后的数据ecmwf
##        测站所处气压层信息level_up,level_down
##        测站每个时间间隔的气压/温度/绝对湿度SitePressure,SiteTemperature,SiteSpecificHumidity
##        测站当地重力加速度g
## Output ZWD{hr} 单位m         1N=1kg·m/s^2,1J=N·m
## ReferencePaper <Impact of GPS Zenith Tropospheric Delay data on precipitation forecasts in Mediterranean France and Spain>
def ZWDFromIntegration(ecmwf,level_up,level_down,SitePressure,SiteTemperature,SiteSpecificHumidity,g):
	ZWD={}

	R=461.51  ## J/(Kg*K) Rw=461.51 Rd=287
	kpi=2.21*1.e-5 ## K/hPa
	k3=3.739*1.e-1   ## K**2/hPa
	for hr in ecmwf.keys():
		listQ=[]
		listT=[]
		listP=[]
		## For the case: below all levels
		if hr not in level_down.keys():
			for pr in ecmwf[hr].keys():
				listQ.append(ecmwf[hr][pr][133])
				listT.append(ecmwf[hr][pr][130])
				listP.append(int(pr))
		## Normal case
		else:
			for pr in ecmwf[hr].keys():
				if int(level_up[hr]) >= int(pr):
					listQ.append(ecmwf[hr][pr][133])
					listT.append(ecmwf[hr][pr][130])
					listP.append(int(pr))
		## 由低大气压到高大气压（高空至测站高度）
		listQ.append(SiteSpecificHumidity[hr])
		listT.append(SiteTemperature[hr])
		listP.append(SitePressure[hr])
		## 求解ZWD
		sum=0.0
		for i in range(len(listQ)-1,0,-1):
			meanT=(listT[i-1]+listT[i])/2
			meanQ=(listQ[i-1]+listQ[i])/2
			sum=sum+abs(listP[i-1]-listP[i])*(kpi+k3/meanT)*meanQ
		ZWD[hr]=R/g*sum
	return ZWD


## 根据测站所在气压层区间，采用双线性内插、垂直温度递减率进行压强与温度的垂直内插
## Input  水平内插后数据ecmwf
##        测站所处气压层信息level_up_up,level_up,level_down
##        测站正高orth_height
## Output 一天内每小时气压/温度/绝对湿度pressures,temperatures,specific_humiditys,relative_humiditys
def VerticalInterpolation_PTQ(ecmwf,level_up_up,level_up,level_down,orth_height):
	pressures={}
	temperatures={}
	specific_humiditys={}
	relative_humiditys={}
	for hr in ecmwf.keys():
		## For the case: below all levels
		if hr not in level_down.keys():
			## pressure
			hp=(ecmwf[hr][level_up_up[hr]][129]-ecmwf[hr][level_up[hr]][129])/math.log(level_up[hr]*1.0/(level_up_up[hr]*1.0))
			pressure=level_up[hr]*math.exp(-(orth_height-ecmwf[hr][level_up[hr]][129])/hp)
			
			omega=(ecmwf[hr][level_up_up[hr]][129]-ecmwf[hr][level_up[hr]][129])/(ecmwf[hr][level_up[hr]][129]-orth_height)
			## temperature
			temperature=-(ecmwf[hr][level_up_up[hr]][130]-ecmwf[hr][level_up[hr]][130])/omega+ecmwf[hr][level_up[hr]][130]
			## specific humidity
			specific_humidity=-(ecmwf[hr][level_up_up[hr]][133]-ecmwf[hr][level_up[hr]][133])/omega+ecmwf[hr][level_up[hr]][133]
			## relative humidity
			relative_humidity=-(ecmwf[hr][level_up_up[hr]][157]-ecmwf[hr][level_up[hr]][157])/omega+ecmwf[hr][level_up[hr]][157]
		## Normal case
		else:
			## pressure
			hp=(ecmwf[hr][level_up[hr]][129]-ecmwf[hr][level_down[hr]][129])/math.log(level_down[hr]*1.0/(level_up[hr]*1.0))
			pressure=level_down[hr]*math.exp(-(orth_height-ecmwf[hr][level_down[hr]][129])/hp)
			
			omega=(ecmwf[hr][level_up[hr]][129]-orth_height)/(ecmwf[hr][level_up[hr]][129]-ecmwf[hr][level_down[hr]][129])
			## temperature
			temperature=ecmwf[hr][level_up[hr]][130]*(1-omega)+ecmwf[hr][level_down[hr]][130]*omega
			## specific humidity
			specific_humidity=ecmwf[hr][level_up[hr]][133]*(1-omega)+ecmwf[hr][level_down[hr]][133]*omega
			## relative humidity
			relative_humidity=ecmwf[hr][level_up[hr]][157]*(1-omega)+ecmwf[hr][level_down[hr]][157]*omega
			
		pressures[hr]=pressure
		temperatures[hr]=temperature
		specific_humiditys[hr]=specific_humidity
		relative_humiditys[hr]=relative_humidity
	return pressures,temperatures,specific_humiditys,relative_humiditys


## 根据测站经纬度以及格网点的经纬度求水平内插系数
## Input  格网点经纬度列表gridlatlist,gridlonlist
##        格网点数据ecmwf1,ecmwf2,ecmwf3,ecmwf4
##        测站点经纬度lat,lon
## Output 水平内插结果ecmwf{hour{pressure{ID}}}
def HorizontalInterpolation(ecmwf1,ecmwf2,ecmwf3,ecmwf4,gridlatlist,gridlonlist,lat,lon,earth_g):
	ecmwf={}
	## Get Four Point around the station
	b1=gridlatlist[0]*deg2rad
	b2=gridlatlist[1]*deg2rad
	b3=gridlatlist[2]*deg2rad
	b4=gridlatlist[3]*deg2rad
	l1=gridlonlist[0]*deg2rad
	l2=gridlonlist[1]*deg2rad
	l3=gridlonlist[2]*deg2rad
	l4=gridlonlist[3]*deg2rad
	
	## Calculate cofficients of  horizontal interpolation, degrees need to convert to rad
	w_tmp1=math.acos(math.sin(l1)*math.sin(lon*deg2rad)+math.cos(l1)*math.cos(lon*deg2rad)*math.cos(b1-lat*deg2rad))
	w_tmp2=math.acos(math.sin(l2)*math.sin(lon*deg2rad)+math.cos(l2)*math.cos(lon*deg2rad)*math.cos(b2-lat*deg2rad))
	w_tmp3=math.acos(math.sin(l3)*math.sin(lon*deg2rad)+math.cos(l3)*math.cos(lon*deg2rad)*math.cos(b3-lat*deg2rad))
	w_tmp4=math.acos(math.sin(l4)*math.sin(lon*deg2rad)+math.cos(l4)*math.cos(lon*deg2rad)*math.cos(b4-lat*deg2rad))
	sum_tmp=math.pow(earth_r*w_tmp1,-1)+math.pow(earth_r*w_tmp2,-1)+math.pow(earth_r*w_tmp3,-1) \
	+math.pow(earth_r*w_tmp4,-1)
	w1=math.pow(earth_r*w_tmp1,-1)/sum_tmp
	w2=math.pow(earth_r*w_tmp2,-1)/sum_tmp
	w3=math.pow(earth_r*w_tmp3,-1)/sum_tmp
	w4=math.pow(earth_r*w_tmp4,-1)/sum_tmp
	
	## horizontal interpolation
	for hr in ecmwf1.keys():
		if hr not in ecmwf.keys(): ecmwf[hr]={}
		for pr in ecmwf1[hr].keys():
			if pr not in ecmwf[hr].keys():ecmwf[hr][pr]={}
			for id in ecmwf1[hr][pr].keys():
				ecmwf[hr][pr][id]=ecmwf1[hr][pr][id]*w1+ecmwf2[hr][pr][id]*w2+ecmwf3[hr][pr][id]*w3 \
				+ecmwf4[hr][pr][id]*w4
				## Calculate geopotential height in meters  approximatelly eaqual to orthometric height
				if id == 129: ecmwf[hr][pr][id]=ecmwf[hr][pr][id]/earth_g
	
	return ecmwf


## 根据水平内插后的数据、测站正高求出测站所在气压层
## Input  水平内插后的数据ecmwf
##        测站正高orth_height
## Output 每个小时测站所处的气压层
##        测站高度低于所有气压层，有效返回值为level_up_up,level_up
##        测站高度处于某两个气压层之间，有效返回值为level_up,level_down
def PressureLevelDetermination(ecmwf,orth_height):
	level_down={}
	level_up={}
	level_up_up={}
	## Horizontal interpolation and choose two levels up and below the height of site
	for hr in ecmwf.keys():
		height_max=1000000
		height_min=-1000000
		for pr in ecmwf[hr].keys():
			## Select the two levels
			if ecmwf[hr][pr][129] > orth_height and ecmwf[hr][pr][129] < height_max:
				level_up[hr]=pr
				height_max=ecmwf[hr][pr][129]
			if ecmwf[hr][pr][129] < orth_height and ecmwf[hr][pr][129] > height_min:
				level_down[hr]=pr
				height_min=ecmwf[hr][pr][129]
		# In case of the site is below all levels, choose the two lower levels
		if height_min == -1000000:
			height_max=1000000
			for prr in ecmwf[hr].keys():
				if ecmwf[hr][prr][129] > ecmwf[hr][level_up[hr]][129] and ecmwf[hr][prr][129] < height_max:
					level_up_up[hr]=prr
					height_max=ecmwf[hr][prr][129]
	return level_up_up,level_up,level_down

## 使用 Wexler-Greenspan 计算饱和水汽压
## 参考文献：董双林, & 崔宏光. (1992). 饱和水汽压计算公式的分析比较及经验公式的改进. 应用气象学报, 3(4), 501-508.
## Input 水平内插后的数据ecmwf
##       测站所处气压层信息level_up,level_down
##       测站每个时间间隔的温度/相对湿度SiteTemperature,SiteRelativeHumidity
##       测站正高orth_height
## Output Tm{hr} 无量纲     
def CalculateTm(ecmwf,level_up,level_down,SiteTemperature,SiteRelativeHumidity,orth_height):
	
	#method='Wexler-Greenspan'
	method='ITS-90'
	
	Tm={}
	for hr in ecmwf.keys():
		listT=[]
		listH=[]
		listEreal=[]
		## For the case: below all levels
		if hr not in level_down.keys():
			for pr in ecmwf[hr].keys():
				listT.append(ecmwf[hr][pr][130])
				listH.append(ecmwf[hr][pr][129])
				Ttmp=ecmwf[hr][pr][130]
				RHtmp=ecmwf[hr][pr][157]
				Ew=SaturationWaterVaporPressure(Ttmp,method) ## Ttmp[K],Ew[Pa]
				## 实际水汽压=相对湿度*饱和水汽压 Pa
				listEreal.append(RHtmp*Ew)
		## Normal case
		else:
			for pr in ecmwf[hr].keys():
				if int(level_up[hr]) >= int(pr):
					listT.append(ecmwf[hr][pr][130])
					listH.append(ecmwf[hr][pr][129])
					Ttmp=ecmwf[hr][pr][130]
					RHtmp=ecmwf[hr][pr][157]
					Ew=SaturationWaterVaporPressure(Ttmp,method) ## Ttmp[K],Ew[Pa]
					## 实际水汽压=相对湿度*饱和水汽压 Pa
					listEreal.append(RHtmp*Ew)
		## 由低大气压到高大气压（高空至测站高度）
		listT.append(SiteTemperature[hr])
		listH.append(orth_height)
		Ttmp=SiteTemperature[hr]
		RHtmp=SiteRelativeHumidity[hr]
		Ew=SaturationWaterVaporPressure(Ttmp,method) ## Ttmp[K],Ew[Pa]
		## 实际水汽压=相对湿度*饱和水汽压 Pa
		listEreal.append(RHtmp*Ew)
		
		## 求解Tm
		sumup=0.0
		sumdown=0.0
		for i in range(len(listT)-1,0,-1):
			meanT=(listT[i-1]+listT[i])/2
			meanEreal=(listEreal[i-1]+listEreal[i])/2
			diffH=abs(listH[i-1]-listH[i])
			sumup=sumup+diffH*meanEreal/meanT
			sumdown=sumdown+diffH*meanEreal/(meanT**2)
		Tm[hr]=sumup/sumdown
	return Tm

## 计算饱和水汽压
## Input:  T in Kelvin, method(Wexler-Greenspan/ITS-90)
## Output: 饱和水汽压Pa
def SaturationWaterVaporPressure(T,method):
	if method == 'Wexler-Greenspan':
		## Wexler-Greenspan 系数
		C0=-0.60436117*1.e4
		C1=0.189318833*1.e2
		C2=-0.28238594*1.e-1
		C3=0.17241129*1.e-4
		C4=0.2858487*10
		Ew=math.exp(C0*T**(-1)+C1*T**0+C2*T**1+C3*T**2+C4*math.log(T)) ## unit Pa
	elif method == 'ITS-90':
		### Hardy  ITS-90 饱和水汽压计算公式 
		##  水面上的系数
		g0=-2.8365744*1.e3
		g1=-6.028076559*1.e3
		g2=1.954263612*10
		g3=-2.737830188*1.e-2
		g4=1.6261698*1.e-5
		g5=7.0229056*1.e-10
		g6=-1.8680009*1.e-13
		g7=2.7150305
		##  冰面系数
		k0=-5.8666426*1.e3
		k1=2.232870244*10 
		k2=1.39387003*1.e-2
		k3=-3.4262402*1.e-5
		k4=2.7040955*1.e-8
		k5=6.7063522*1.e-1
		
		if T - 273.15 > 0:
			Ew=math.exp(g0*T**(-2)+g1*T**(-1)+g2*T**(0)+g3*T**1+g4*T**2+g5*T**3+g6*T**4+g7*math.log(T))
		else:
			Ew=math.exp(k0*T**(-1)+k1*T**(0)+k2*T**(1)+k3*T**2+k4*T**3+k5*math.log(T))
	else:
		Ew=999999
	return Ew

## 直接根据气象元素求PWV[mm]
## Input: 水平内插后的数据ecmwf
##        测站所处气压层信息level_up,level_down
##        测站每个时间间隔的压强/比湿SitePressure/SiteSpecificHumidity
##        重力加速度g
## Output: PWV mm
def MeteoElement2PWV(ecmwf,level_up,level_down,SitePressure,SiteSpecificHumidity,g):
	rhow=999.97   # Dichte von Wasser kg/m**3
	PWV={}
	for hr in ecmwf.keys():
		listQ=[]
		listP=[]
		## For the case: below all levels
		if hr not in level_down.keys():
			for pr in ecmwf[hr].keys():
				listQ.append(ecmwf[hr][pr][133])
				listP.append(int(pr))
		## Normal case
		else:
			for pr in ecmwf[hr].keys():
				if int(level_up[hr]) >= int(pr):
					listQ.append(ecmwf[hr][pr][133])
					listP.append(int(pr))
		## 由低大气压到高大气压（高空至测站高度）
		listQ.append(SiteSpecificHumidity[hr])
		listP.append(SitePressure[hr])
		
		## 求解PWV
		## 比湿Q[kg/kg],压强P[hPa],重力加速度g[m/s^2]
		sum=0.0
		for i in range(len(listQ)-1,0,-1):
			meanQ=(listQ[i-1]+listQ[i])/2
			sum=sum+100*abs(listP[i-1]-listP[i])*meanQ/(rhow*g) # hPa=100*1Pa
		PWV[hr]=sum*1000 ## unit  m->mm
	return PWV


## 根据grib文件，测站名，经纬度，大地高，正高求测站温度/气压/ZHD/ZWD
## Input  ecmwf_file, site, lat, lon, ell_height, orth_height [str,str,float,float,float,float]
## Output pressures,temperatures,ZHD,ZWD,Tm,specificHumidity,relativeHumidity,PWV_Direct
def decode_interpolation(which_soft,ecmwf_file,site,lat,lon,ell_height,orth_height):
	## Decode grib of four point unit is degree
	time1=time.time()
	os.system('grib_ls'+which_soft+' -l '+str(lat)+','+str(lon)+',4 -p centre,dataDate,hour,level,paramId '+ecmwf_file+' > '+site+'_4point')
	time2=time.time()
	print('Decoding Time For %s : %12.6f min' % (site,(time2-time1)/60))
	ecmwf1,ecmwf2,ecmwf3,ecmwf4,latlist,lonlist=read_decoded_file(site+'_4point')
	os.remove(site+'_4point')
	## 求当地重力加速度
	g=cal_gravity(lat*deg2rad,ell_height)
	## 水平内插
	ecmwf=HorizontalInterpolation(ecmwf1,ecmwf2,ecmwf3,ecmwf4,latlist,lonlist,lat,lon,g)
	## 确定所处气压层
	level_up_up,level_up,level_down=PressureLevelDetermination(ecmwf,orth_height)
	## 温度压强绝对湿度垂直内插
	pressures,temperatures,specificHumidity,relativeHumidity=VerticalInterpolation_PTQ(ecmwf,level_up_up,level_up,level_down,orth_height)
	## 求取时间间隔ZWD[m]
	ZWD=ZWDFromIntegration(ecmwf,level_up,level_down,pressures,temperatures,specificHumidity,g)
	## 求取时间间隔ZHD[m]
	ZHD=ZHDFromSaastamoinen(pressures,lat*deg2rad,ell_height)
	## 求取Tm
	Tm=CalculateTm(ecmwf,level_up,level_down,temperatures,relativeHumidity,orth_height)
	## get PWV directly
	PWV_Direct=MeteoElement2PWV(ecmwf,level_up,level_down,pressures,specificHumidity,g)
	return pressures,temperatures,ZHD,ZWD,Tm,specificHumidity,relativeHumidity,PWV_Direct


## Main Function
## WorkDir 工作目录; CalYear 年份; begDOY 开始年积日;
## ndays 天数; sitelist 测站列表; which_soft 避免出错同一时间选择不同软件来跑
## Warning: 在不同文件夹里面提供cf_net(测站坐标)
def main(WorkDir,CalYear,begDOY,ndays,sitelist,which_soft):
	try:
		## cd WorkDir
		os.chdir(WorkDir)
		## delete INPUT.DAT
		if os.access("INPUT.DAT", os.F_OK): os.remove("INPUT.DAT")
		## generate INPUT.DAT [Format: YYYYDDD 站名 纬度 经度 大地高]
		for idoy in range(begDOY,begDOY+ndays):
			generate_blh(sitelist,CalYear,idoy)
		### generate OUTPUT.DAT  [Format: YYYYDDD 站名 纬度 经度 大地高 大地水准面差异 正高]
		os.system(interpsoft)
		### Read OUTPUT.DAT, decode grib file as well as save values in ecmwfdata
		ecmwfdata={}
		with open("OUTPUT.DAT","r") as fr:
			for line in fr:
				v_list = line.split()
				idoy=int(v_list[0][4:])
				strsite=v_list[1]
				if strsite not in ecmwfdata.keys(): ecmwfdata[strsite]={}
				if idoy not in ecmwfdata[strsite].keys(): 
					ecmwfdata[strsite][idoy]={}
					mmdd=os.popen("jday " + v_list[0][4:7] + " " + v_list[0][0:4]).read()[0:4]
					yyyy=os.popen("jday " + v_list[0][4:7] + " " + v_list[0][0:4]).read()[4:8]
					ecmwf_file=ecmwf_grib.replace("YYYYMMDD",yyyy+mmdd)
					print('%s %s' % (v_list[0],ecmwf_file))
				
				### Saved Data   ell mean ellipsoidal, orth mean orthometric
				ecmwfdata[strsite][idoy]["lat"]=float(v_list[2])
				ecmwfdata[strsite][idoy]["lon"]=float(v_list[3])
				ecmwfdata[strsite][idoy]["ellheight"]=float(v_list[4])
				ecmwfdata[strsite][idoy]["ortheight"]=float(v_list[6])
				### For interpolation
				lat=float(v_list[2])
				lon=float(v_list[3])
				ell_height=float(v_list[4])
				orth_height=float(v_list[6])
				
				pressures,temperatures,ZHD,ZWD,Tm,sH,rH,PWVdirect=decode_interpolation(which_soft,ecmwf_file,strsite,lat,lon,ell_height,orth_height)
				
				for hr in temperatures.keys():
					if hr not in ecmwfdata[strsite][idoy].keys():ecmwfdata[strsite][idoy][hr]={}
					ecmwfdata[strsite][idoy][hr]["Temperature"]=temperatures[hr]
					ecmwfdata[strsite][idoy][hr]["Pressure"]=pressures[hr]
					ecmwfdata[strsite][idoy][hr]["ZHD"]=ZHD[hr]
					ecmwfdata[strsite][idoy][hr]["ZWD"]=ZWD[hr]
					ecmwfdata[strsite][idoy][hr]["Tm"]=Tm[hr]
					ecmwfdata[strsite][idoy][hr]["sH"]=sH[hr]
					ecmwfdata[strsite][idoy][hr]["rH"]=rH[hr]
					ecmwfdata[strsite][idoy][hr]["PWVdirect"]=PWVdirect[hr]
					
		### Write result file Per station [Format: 时间 纬度/° 经度/° 大地高m 正高m 比湿kg/kg 相对湿度% 大气压hPa 温度K ZHD/mm ZWD/mm Tm/K PWV/mm PWVdirect/mm]
		f2=open("EcmwfInfoPWV","w")
		for strsite in ecmwfdata.keys():
			f=open("PTZhwtDTm_"+strsite,"w")
			for idoy in range(begDOY,begDOY+ndays):
				mmdd=os.popen("jday " + str(idoy) + " " + str(CalYear)).read()[0:4]
				yyyy=os.popen("jday " + str(idoy) + " " + str(CalYear)).read()[4:8]
				lat=ecmwfdata[strsite][idoy]["lat"] #°
				lon=ecmwfdata[strsite][idoy]["lon"] #°
				ellheight=ecmwfdata[strsite][idoy]["ellheight"] #m
				ortheight=ecmwfdata[strsite][idoy]["ortheight"] #m
				for iter in ecmwfdata[strsite][idoy].keys():
					if iter != "lat" and iter != "lon" and iter != "ellheight" and iter != "ortheight":
						p=ecmwfdata[strsite][idoy][iter]["Pressure"] #hPa=mbar
						t=ecmwfdata[strsite][idoy][iter]["Temperature"] #K
						onezhd=1000*ecmwfdata[strsite][idoy][iter]["ZHD"] #mm
						onezwd=1000*ecmwfdata[strsite][idoy][iter]["ZWD"] #mm
						oneztd=onezhd+onezwd #mm
						onetm=ecmwfdata[strsite][idoy][iter]["Tm"] #K
						onepwv=zwd2pwv(onezwd,onetm) ##mm
						onesH=ecmwfdata[strsite][idoy][iter]["sH"]
						onerH=ecmwfdata[strsite][idoy][iter]["rH"]
						onePWVdirect=ecmwfdata[strsite][idoy][iter]["PWVdirect"]
						##tmBevis=70.2+0.72*t######
						info=yyyy+mmdd+"  "+strsite+"  "+str(iter).zfill(2)+"  "
						##f.write('%s%17.10f%17.10f%14.4f%14.6f%14.6f%11.5f%11.5f%11.5f%15.8f%11.5f\n' % (info,lat,lon,ellheight,p,t,onezhd,onezwd,oneztd,onetm,onepwv))
						f.write('%s%17.10f%17.10f%14.4f%14.4f%18.13f%15.10f%14.6f%14.6f%12.5f%12.5f%15.8f%12.5f%12.5f\n' % (info,lat,lon,ellheight,ortheight,onesH,onerH,p,t,onezhd,onezwd,onetm,onepwv,onePWVdirect))
						f2.write('%s%17.10f%17.10f%14.4f%14.4f%18.13f%15.10f%14.6f%14.6f%12.5f%12.5f%15.8f%12.5f%12.5f\n' % (info,lat,lon,ellheight,ortheight,onesH,onerH,p,t,onezhd,onezwd,onetm,onepwv,onePWVdirect))
			f.close()
		f2.close()
	except:
		if VERBOSE:
			traceback.print_exc(file=sys.stderr)
		else:
			sys.stderr.write(err.msg + '\n')
		return 1


if __name__ == "__main__":
	if (len(sys.argv)<7):
		print("Argument Number is Wrong")
	else:
		print(sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],sys.argv[6])
		workdir=sys.argv[1]
		year=int(sys.argv[2])
		beg=int(sys.argv[3])
		ndays=int(sys.argv[4])
		sitelist=sys.argv[5]
		if sys.argv[6] == "0":
			which_soft=""
		else:
			which_soft=sys.argv[6]
		
		
		sys.exit(main(workdir,year,beg,ndays,sitelist,which_soft))
