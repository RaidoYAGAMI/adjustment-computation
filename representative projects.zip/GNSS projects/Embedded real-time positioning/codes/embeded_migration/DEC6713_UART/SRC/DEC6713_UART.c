
/*********************************************************************************
* DEC6713_UART.C	v2.00	     							                            *
* Copyright	2003 by SEED Electronic Technology Ltd.
* All rights reserved. Property of SEED Electronic Technology Ltd.			                *
* Designed by:	Hongshuai.Li
* Discription:Operation mode is FIFO.
* 05.10.2005	
*********************************************************************************/
#include <csl.h>
#include <csl_irq.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "DEC6713.h"
#include "uartn.h"
#include "SPPconstFUNC.h"
/********************************************************************************/



#define LENGTH 160

Uint32 UART_Handle;
Uint32 UARTA_Handle;		//added on 03.04.2005
Uint32 UARTB_Handle;
Uint8 RevBuffer_A[160];
Uint8 RevBuffer_B[160];
Uint16 i;
Uint8 int_flag = 1;
Uint8 TempData;
Uint16 BaudRate;
Uint8 reg_data=0;
Uint8 Lth = 0;

Uint8 RcountA =0;
Uint8 RcountB =0;
Uint8 ScountA =0;
Uint8 ScountB =0;
Uint8 ReVal = 0;
#pragma DATA_SECTION(uart_ab_channel_select,".uart_var");
unsigned char uart_ab_channel_select = 0;
/********************************************************************************/
void init_uart();		//added on 03.04.2005
extern far void vectors();

raw RAW;
SPPresult spp;
positionresult posdata;
unsigned char buff1[MAXLEN], buff2[MAXLEN];

main()
{

	
	int result,sppresult;
	FILE *Fobs;
	FILE *Fpwrite;
	//FILE *Fposwrite;

	/* Initialize the chip support library, must when using CSL */
  	CSL_init(); 
	/*Initializ
	//DEC6713_init();
	
	
	/*Initialize receive buffer.*/
	for(i=0;i<LENGTH;i++)
	{
		RevBuffer_A[i] = 0;
		RevBuffer_B[i] = 0;
		//TxmBuffer[i] = i;
	}

	/* Disable interrupt. */
	IRQ_globalDisable();
	IRQ_RSET(EXTPOL,0x0F);
	IRQ_setVecs(vectors);
	IRQ_map(IRQ_EVT_EXTINT6,6);
	IRQ_disable(IRQ_EVT_EXTINT6);
	IRQ_clear(IRQ_EVT_EXTINT6);
	
	/*Open UART. */
	init_uart();
	
	/* Enable interrupt */
	IRQ_enable(IRQ_EVT_EXTINT6);
	IRQ_globalEnable();
	IRQ_nmiEnable();
	
	
	result=0;
	sppresult=0;
	sppresult=0;
	//���岢��ʼ��������ݽṹ�����
	memset(&RAW, 0, sizeof(raw));
	memset(&posdata, 0, sizeof(positionresult));


	if ((Fobs = fopen("C:\\Users\\lenovo\\Desktop\\201502071.bin", "rb")) == NULL)
	{
		printf("Cannot open novAtel binary file. \n");
		return 0;
	}	
	if ((Fpwrite = fopen("C:\\Users\\lenovo\\Desktop\\SPPSPVresult.txt", "a+")) == NULL)
	{
		printf("Cannot open result file. \n");
		return 0;
	}	
	/*if ((Fposwrite = fopen("C:\\Users\\lenovo\\Desktop\\PSRPOSresult.txt", "a+")) == NULL)
	{
		printf("Cannot open PSRPOS result file. \n");
	}*/

	//�������ݽ���
	while (!feof(Fobs))
	{
		result = NovAtelDataAcquire(&RAW, Fobs, &posdata,buff1,buff2);
		if (result == 4)
		{
			sppresult = SinglePointP(&spp, &RAW);
			if (sppresult == 0)
			{
				continue;
			}
			else
			{
				//��������浽�ļ���
				fprintf(Fpwrite, "%d %lf \n", RAW.obstime.Week, RAW.obstime.SecOfWeek);
				fprintf(Fpwrite, "%.9lf %.9lf %.9lf %.9lf %.9lf %.9lf \n", spp.location.COOR_x, spp.location.COOR_y, spp.location.COOR_z, spp.sigma, spp.DOP, spp.PDOP);
				//���е������
				SinglePointV(&spp, &RAW);
				/*��������浽�ļ���*/
				fprintf(Fpwrite, "%.9lf %.9lf %.9lf %.9lf \n", spp.SPEED[0], spp.SPEED[1], spp.SPEED[2], spp.sigma);
			}
		}
		/*if (result == 5)
		{
			fprintf(Fposwrite, "%d %lf \n", posdata.postime.Week, posdata.postime.SecOfWeek);
			fprintf(Fposwrite, "%lf %lf %lf \n", posdata.lat, posdata.lon, posdata.hgt + posdata.undulation);
		}*/
	}

	fclose(Fobs);
	fclose(Fpwrite);
	//fclose(Fposwrite);
}
/********************************************************************************\
\*UART initialize routine	*\		//added on 03.04.2005
\********************************************************************************/
void init_uart()
{
	/* Initialize uart_a */
		UARTA_Handle = UART_open(UART_A);
		BaudRate = baud_9k6;
		UART_setup(UARTA_Handle,BaudRate,
					data_w8,
					data_s1,
					0,
					0x07,
					0x08);
					
		/* Clear RHR and LSR registers. */	
		TempData = UART_rget(UARTA_Handle,UART_RHR);
		TempData = UART_rget(UARTA_Handle,UART_LSR);
	
		/* Setup UARTA interrupt. */
		UART_IntSetup(UARTA_Handle,uartint_rhr);
		
	/* Initialize uart_b */
		UARTB_Handle = UART_open(UART_B);
		BaudRate = baud_19k2;
		UART_setup(UARTB_Handle,BaudRate,
					data_w8,
					data_s1,
					0,
					0x07,
					0x08);
					
		/* Clear RHR and LSR registers. */	
		TempData = UART_rget(UARTB_Handle,UART_RHR);
		TempData = UART_rget(UARTB_Handle,UART_LSR);
	
		/* Setup UARTA interrupt. */
		UART_IntSetup(UARTB_Handle,uartint_rhr);


}

/********************************************************************************\
\*	-UART interrupt handle function.
\*Parameters:
\*
\*Return:
\********************************************************************************/

interrupt void
c_int6(void)
{
	/*Receive data and save in data_buffer.*/
	reg_data = DEC6713_cpld_rget(DEC6713_INTSTAT_REG);
	
	// Receive UARTA data
	if((reg_data & 0x60) == 0x20)
	{
		TempData = UART_rget(UARTA_Handle,UART_LSR);
		if((TempData&0x01) == 0x01)
		{
		
			for(i=0;i<FIFO_Length;i++)
			{	
				//DEC6713_wait(BaudRate/baud_38k4 * 2026);
				RevBuffer_A[RcountA]=UART_receive_single(UARTA_Handle);
			}
			RcountA++;		
			if(RcountA == 160) RcountA =0;
				
		}
		
		else
		{
			UART_rset(UARTA_Handle,UART_FCR,0x02);
		}
	}
		
		
	
	// Receive UARTb data
	if((reg_data & 0x60) == 0x40)
	{
		TempData = UART_rget(UARTB_Handle,UART_LSR);
		if((TempData&0x01) == 0x01)
		{	
		
			for(i=0;i<FIFO_Length;i++)
			{
			
			//	DEC6713_wait(BaudRate/baud_38k4 * 2026);
				RevBuffer_B[RcountB]=UART_receive_single(UARTB_Handle);
			}
			RcountB++;
			if(RcountB == 160) RcountB =0;
		}
		
		else
		{
			UART_rset(UARTB_Handle,UART_FCR,0x02);
		}
				
	}	
	int_flag = 0;
	return;
}
/********************************************************************************/
/*	End of DEC6713_UART.C */
/********************************************************************************/

