
/*********************************************************************************
* DEC6713_UART.C	v1.00	     							                            *
* Copyright	2003 by SEED Electronic Technology Ltd.
* All rights reserved. Property of SEED Electronic Technology Ltd.			                *
* Designed by:	Hongshuai.Li	
*********************************************************************************/
#include <csl.h>
#include <csl_irq.h>
#include "DEC6713.h"
#include "uart.h"
#include <stdio.h>
/********************************************************************************/



#define LENGTH 100

Uint32 UART_Handle;
Uint32 UARTA_Handle;		//added on 03.04.2005
Uint32 UARTB_Handle;
Uint8 RevBuffer_A[LENGTH];
Uint8 RevBuffer_B[LENGTH];
Uint16 i;
Uint8 int_flag = 1;
Uint8 TempData;
Uint16 BaudRate;
Uint16 DelayLength = 5924;
Uint8 reg_data=0;
Uint8 Lth = 0;

#pragma DATA_SECTION(uart_ab_channel_select,".uart_var");
unsigned char uart_ab_channel_select = 0;
/********************************************************************************/
void init_uart();		//added on 03.04.2005
extern far void vectors();
main()
{

	/* Initialize the chip support library, must when using CSL */
  	CSL_init(); 
	/*Initialize DEC6713 board.*/
	DEC6713_init();
	
	
	// Start added on 2005.1.27
	// Testing delay time
	//asm("nop");
	//DEC6713_wait(0x1000);
	//asm("nop");
	// End added on 2005.1.27
	/*Initialize receive buffer.*/
	for(i=0;i<LENGTH;i++)
	{
		RevBuffer_A[i] = 0;
		RevBuffer_B[i] = 0;
		//TxmBuffer[i] = i;
	}

	/* Disable interrupt. */
	IRQ_globalDisable();
	IRQ_RSET(EXTPOL,0x0F);
	IRQ_setVecs(vectors);
	IRQ_map(IRQ_EVT_EXTINT6,6);
	IRQ_disable(IRQ_EVT_EXTINT6);
	IRQ_clear(IRQ_EVT_EXTINT6);
	
	/*Open UART. */
	//UART_Handle = UART_open(UART_A);	deleted on 03.04.2005
	/*Setup UART X.*/
	/*deleted on 03.04.2005
	BaudRate = baud_9k6;
	UART_setup(UART_Handle,BaudRate,
					data_w8,
					data_s1,
					0,
					FIFO_disable,
					0);
	*/
	/* Clear RHR and LSR registers. */	
	//TempData = UART_rget(UART_Handle,UART_RHR);deleted on 03.04.2005
	//TempData = UART_rget(UART_Handle,UART_LSR);deleted on 03.04.2005
	
	/* Setup UART interrupt. */
	//UART_IntSetup(UART_Handle,uartint_rhr);deleted on 03.04.2005
	
	/*Initialize UART*/		//added on 03.04.2005
	init_uart();
	
	/* Enable interrupt */
	IRQ_enable(IRQ_EVT_EXTINT6);
	IRQ_globalEnable();
	IRQ_nmiEnable();
	
	
	while(1)
	{
		/* Wait receive interrupt. */
		while(int_flag)
		{
			/*Receive data from PC.*/
		}
		/*Transmit received data to PC.*/
		/*
		if(Lth)
		{
			UART_send(UARTA_Handle,BaudRate,Lth,RevBuffer_A);
			UART_send(UARTB_Handle,BaudRate,Lth,RevBuffer_B);
		}
		else
		{
			UART_send(UARTA_Handle,BaudRate,100,RevBuffer_A);
			UART_send(UARTB_Handle,BaudRate,100,RevBuffer_B);
		}
		
		*/			// the same to Programe1.1
		if((uart_ab_channel_select & 0x01) == 0x01)
		{
			if(Lth)
			{
				UART_send(UARTA_Handle,BaudRate,Lth,RevBuffer_A);
				//UART_send(UARTB_Handle,BaudRate,Lth,RevBuffer_B);
			}
			else
			{
				UART_send(UARTA_Handle,BaudRate,100,RevBuffer_A);
				//UART_send(UARTB_Handle,BaudRate,100,RevBuffer_B);
			}
			int_flag=1;
		}
		if((uart_ab_channel_select & 0x02) == 0x02)
		{
			if(Lth)
			{
				//UART_send(UARTA_Handle,BaudRate,Lth,RevBuffer_A);
				UART_send(UARTB_Handle,BaudRate,Lth,RevBuffer_B);
			}
			else
			{
				//UART_send(UARTA_Handle,BaudRate,100,RevBuffer_A);
				UART_send(UARTB_Handle,BaudRate,100,RevBuffer_B);
			}
				int_flag=1;
		}
		//int_flag=1;
	}
}
/********************************************************************************\
\*UART initialize routine	*\		//added on 03.04.2005
\********************************************************************************/
void init_uart()
{
	/* Initialize uart_a */
		UARTA_Handle = UART_open(UART_A);
		BaudRate = baud_19k2;
		UART_setup(UARTA_Handle,BaudRate,
					data_w8,
					data_s1,
					0,
					FIFO_enable,
					0);
					
		/* Clear RHR and LSR registers. */	
		TempData = UART_rget(UARTA_Handle,UART_RHR);
		TempData = UART_rget(UARTA_Handle,UART_LSR);
	
		/* Setup UARTA interrupt. */
		UART_IntSetup(UARTA_Handle,uartint_rhr);
		
	/* Initialize uart_b */
		UARTB_Handle = UART_open(UART_B);
		BaudRate = baud_19k2;
		UART_setup(UARTB_Handle,BaudRate,
					data_w8,
					data_s1,
					0,
					FIFO_disable,
					0);
					
		/* Clear RHR and LSR registers. */	
		TempData = UART_rget(UARTB_Handle,UART_RHR);
		TempData = UART_rget(UARTB_Handle,UART_LSR);
	
		/* Setup UARTA interrupt. */
		UART_IntSetup(UARTB_Handle,uartint_rhr);


}

/********************************************************************************\
\*	-UART interrupt handle function.
\*Parameters:
\*
\*Return:
\********************************************************************************/

interrupt void
c_int6(void)
{
	/*Receive data and save in data_buffer.*/
	reg_data = DEC6713_cpld_rget(DEC6713_INTSTAT_REG);
	
	// Receive UARTA data
	if((reg_data & 0x60) == 0x20)
	{
		for(i=0;i<LENGTH;i++)
		{
			DEC6713_wait(BaudRate/baud_38k4 * 2026);
			//DEC6713_wait(8065);
			RevBuffer_A[i]=UART_receive_single(UARTA_Handle);
			if(RevBuffer_A[i] == 0x0A)
			{
				Lth = i+1;
				break;
			}
		}
	}
			// Receive UARTA data
	if((reg_data & 0x60) == 0x40)
	{
		for(i=0;i<LENGTH;i++)
		{
			DEC6713_wait(BaudRate/baud_38k4 * 2026);
			//DEC6713_wait(8065);
			RevBuffer_B[i]=UART_receive_single(UARTB_Handle);
			if(RevBuffer_B[i] == 0x0A)
			{
				Lth = i+1;
				break;
			}
		}
	}	
	int_flag = 0;
	return;
}
/********************************************************************************/
/*	End of DEC6713_UART.C */
/********************************************************************************/

