
/*********************************************************************************
* UART.C	v1.00	     							                            *
* Copyright	2003 by SEED Electronic Technology Ltd.
* All rights reserved. Property of SEED Electronic Technology Ltd.			                *
* Designed by:	Hongshuai.Li	
*********************************************************************************/
/*UART.C	-UART applyed functions*/
#include <csl.h>
#include "uart.h"
#include "DEC6713.h"

/*******************************************************************************/

/*******************************************************************************\
\*UART_rget()	-Read UART register
\*Parameters��
\*		channel: Channel NO. UART A or UART B..
\*		regnum: The related register��

\*Return: The related register value.
\*******************************************************************************/
Uint16 UART_rget(Uint32 channel,Uint16 regnum)
{
	Uint16 *udata;
	udata = (Uint16 *)(DEC6713_UART_BASE + channel + regnum);
	return (*udata & 0xff);
}
/*******************************************************************************/

/********************************************************************************\
\*UART_rset()	-Write UART register.
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		regnum: The related register��
\*		regval:To be writen register value.

\*Return: NO.
\*******************************************************************************/
void UART_rset(Uint32 channel,Uint16 regnum, Uint8 regval)
{
	Uint16 *udata;
	udata = (Uint16 *)(DEC6713_UART_BASE + channel + regnum);
	*udata = (regval &0xff);
	DEC6713_wait(20000);
}
/********************************************************************************/

/********************************************************************************\
\*UART_open()	-Open the related asynchronous serial port, and return a valid word.
\*Parameters:
\*		uart: the selected serial port.

\*Return:The valid word for the selected serial port.
		 When returning 0xFFFF,it is a invalid word.
\********************************************************************************/
extern Uint32 UART_open(UartId uart)
{
	Uint32 ret_data;
	if(uart == 0)
	{	
		ret_data = 0x00000000;
		return ret_data;
	}
	if(uart ==1)
	{
		ret_data = 0x00040000;
		return  ret_data;
	}
	ret_data = 0xFFFFFFFF;
	return ret_data;
}
/********************************************************************************/

/*******************************************************************************\
\*UART_setup()	-UART setup.
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		UartBaud: UART baudrate.
\*	   	UartWordLen: UART word length.
\* 		UartStopBits: UART stop bits.                                          
\*	   	UartParity:	UART parity.                                            
\*	   	UartFifoControl: UART FIFO control.                                       
\*	   	UartLoopway: UART loop.
\********************************************************************************/
void UART_setup(Uint32 channel,
							Uint16 UartBaud,
							Uint8 UartWordLen,
							Uint8 UartStopBits,
							Uint8 UartParity,
							Uint8 UartFifoControl,
							Uint8 UartLoopway)
{
	Uint8 baudratel,baudrateh,uartdata;
	/* Set clock divisor as "1" */
	UART_rset(channel,UART_LCR,0xBF);
	UART_rset(channel,UART_EFR,0x10);
	UART_rset(channel,UART_LCR,0x00);
	UART_rset(channel,UART_MCR,0x00);	
	/* Set baudrate. */
	UART_rset(channel,UART_LCR,0x80);
	
	baudratel = (UartBaud & 0x00ff);
	UART_rset(channel,UART_DLL,baudratel);
	
	baudrateh = (UartBaud & 0xff00) >> 8;
	UART_rset(channel,UART_DLH,baudrateh);
	
	UART_rset(channel,UART_LCR,0x00);
	/* Set word length. */
	uartdata = UartWordLen + UartStopBits + UartParity;
	UART_rset(channel,UART_LCR,uartdata);
	/* Set FIFO parameters. */
	UART_rset(channel,UART_FCR,FIFO_rreset);
	UART_rset(channel,UART_FCR,UartFifoControl);

	UART_rset(channel,UART_MCR,UartLoopway);
	//UART_rset(channel,UART_IER,0x01);// added 2005.4.26
}
/********************************************************************************/

/********************************************************************************\
\*UART_receive_single()	-UART serial data receiving function.
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		rec_dada_add: Start Add for storing reveived data.
\*Return: 0,Finish Receiveng.
		  1,Data not ready.
		  0xFFFF,Port error.
		  2,Interrupt timeout.
\********************************************************************************/
Uint16 UART_receive_single(Uint32 channel)
{
	Uint16 revdata;
	revdata = UART_rget(channel,UART_RHR);
	return(revdata&0xFF);	
}
/********************************************************************************/

/********************************************************************************\
\*UART_send_single()	-Send a set of data.
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		send_data: To be sent data.
\*Return: No.
\********************************************************************************/
void UART_send_single(Uint32 channel,Uint8 send_data)
{
	Uint16 lsrdata;

	do
	{
	lsrdata = UART_rget(channel,UART_LSR);
	}
	while((lsrdata & 0x40) != 0x40);
	UART_rset(channel,UART_THR,send_data);	
}
/********************************************************************************/

/********************************************************************************\
\*UART_send()		-Send data function.
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		length:	Data buffer length.
\*		send_data_add: To be sent data start address.
\********************************************************************************/
void UART_send(Uint32 channel,Uint16 BaudRate,Uint16 length,Uint8 *send_data)
{
	Uint16 i;
	for(i=0;i<length;i++)
	{
		UART_send_single(channel,*send_data++);
		DEC6713_wait((BaudRate/baud_38k4)*2026);
		//DEC6713_wait(8065);
	}
}
/********************************************************************************\
\* UART_IntSetup() - Setup UART interrupt. *\
\* Parameters:
\* Returns:
\********************************************************************************/
void UART_IntSetup(Uint32 channel,Uint8 UartIntn)
{
	UART_rget(channel,UART_LSR);
	UART_rset(channel,UART_IER,UartIntn);
	UART_rset(channel,UART_MCR,0x49);

}
/********************************************************************************\
\* UART_delay()	-UART delay routine			*\
\* Parameters:
\* Return:
\********************************************************************************/

/********************************************************************************/
/* End of UART.C */
/********************************************************************************/

