
/*********************************************************************************
* UART.h	v1.00	     							                            *
* Copyright	2003 by SEED Electronic Technology Ltd.
* All rights reserved. Property of SEED Electronic Technology Ltd.			                *
* Designed by:	Hongshuai.Li	
*********************************************************************************/
#ifndef _UART
#define _UART

#include <csl.h>
/********************************************************************************/
/* Define constant.																	*/
/********************************************************************************/
/* UART instance enumeration*/
typedef enum
{
    UART_A  = 0,
	UART_B  = 1
} UartId, *PUartId;
/********************************************************************************/
/*Set UART registers address ��*/
#define DEC6713_UART_BASE	0xB0080000
//#define DEC6713_UART_BASE	0xB0040000
#define UART_RHR	0x0000<<1
#define UART_THR	0x0000<<1
#define UART_IER	0x0001<<1
#define UART_FCR	0x0002<<1
#define UART_IIR	0x0002<<1
#define UART_LCR	0x0003<<1
#define UART_MCR	0x0004<<1
#define UART_LSR	0x0005<<1
#define UART_MSR	0x0006<<1
#define UART_SPR	0x0007<<1

#define UART_DLL	0x0000<<1
#define UART_DLH	0x0001<<1
#define UART_EFR	0x0002<<1
#define UART_XON1	0x0004<<1
#define UART_XON2	0x0005<<1
#define UART_XOFF1	0x0006<<1
#define UART_XOFF2	0x0007<<1
#define UART_TCR	0x0006<<1
#define UART_TLR	0x0007<<1
#define UART_FDY	0x0007<<1
/*UART channel address*/
#define chanel_a 0x0000<<1/*channel a*/
#define chanel_b 0x0001<<1 /*channel b*/
/*Set UART parameters */
/*Set Baud rate */
#define baud_1k2	0x0620
#define baud_2k4	0x0320
#define baud_4k8	0x0190
#define baud_9k6	0x00c8
#define baud_19k2	0x0064
#define baud_38k4	0x0032
/*word length Set*/
#define data_w5     0x0000 /*length=5*/
#define data_w6     0x0001 /*length=6*/
#define data_w7     0x0002 /*length=7*/
#define data_w8     0x0003 /*length=8*/

#define data_s1     0x0000 /*1 stop bit*/
#define data_s2     0x0004 /*1.5 or 2 stop bit*/

#define data_p      0x0008 /*Set parity bit*/
#define data_po     0x0000 /*odd parity*/
#define data_pe     0x0010 /*even parity*/
#define data_parity 0x0020 /*Set parity bit*/
#define data_break  0x0040 /*output low,when breaking*/
#define uart_parity data_p + data_pe 

/*Set FIFO */
#define FIFO_disable 0x0000 /*Disable FIFO*/
#define FIFO_enable  0x0001 /*Enable FIFO*/
#define FIFO_rreset  0x0002 /*Receive reset.*/
#define FIFO_xreset  0x0004 /*Transmit reset*/
#define FIFO_dma     0x0008 /*Set DMA mode*/
#define FIFO_txdip8    0x0000 /*FIFO TX trigger level is 8 spaces*/
#define FIFO_txdip16   0x0010 /*FIFO TX trigger level is 16 spaces*/
#define FIFO_txdip32   0x0020 /*FIFO TX trigger level is 32 spaces*/
#define FIFO_txdip56   0x0030 /*FIFO TX trigger level is 56 spaces*/
#define FIFO_rxdip8    0x0000 /*FIFO RX trigger level is 8 spaces*/
#define FIFO_rxdip16   0x0040 /*FIFO RX trigger level is 16 spaces*/
#define FIFO_rxdip56   0x0080 /*FIFO RX trigger level is 56 spaces*/
#define FIFO_rxdip60   0x00b0 /*FIFO RX trigger level is 60 spaces*/

#define UartLoop       0x0010 /*Set close loop*/

/*Set UART interrupt */
#define  uartint_rhr   0x0001 /*RHR Interrupt*/
#define  uartint_thr   0x0002 /*THR Interrupt*/
#define  uartint_rls   0x0004 /*Receiver Line Status Interrupt*/
#define  uartint_msr   0x0008/*MODEM Status Interrupt*/
#define  uart_sleep    0x0010 /*Sleep mode*/
#define  uartint_xoff  0x0020 /*Xoff Interrupt*/
#define  uartint_rts   0x0040 /*RTS Interrupt*/
#define  uartint_cts   0x0080 /*CTS Interrupt*/

#define  uartint_enable   0x0008 /*Enable UART Interrupt*/

/********************************************************************************\
\********************************************************************************\
\* Functions Declare.
\********************************************************************************/

/********************************************************************************\
\*UART_open()	-Open the related asynchronous serial port, and return a valid word.
\*Parameters:
\*		uart: the selected serial port.

\*Return:The valid word for the selected serial port.
		 When returning 0xFFFF,it is a invalid word.
\********************************************************************************/
Uint32 UART_open(UartId uart);

/********************************************************************************\
\*UART_rset()	-Write UART registers,initialize UART.
\*Parameters:
\*		channel: Channel NO. indicate UART A or UART B.
\*		regnum: The related register.
\*		regval: The related register value will be written.
\Return:No.
\********************************************************************************/
void UART_rset(Uint32 channel,Uint16 regnum, Uint8 regval);

/********************************************************************************\
\*UART_rget()	-Read UART registers,initialize UART.
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		regnum: The related register.
\*Return: The related register value.
\********************************************************************************/
Uint16 UART_rget(Uint32 channel,Uint16 regnum);

/*******************************************************************************\
\*UART_setup()	-UART setup.
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		UartBaud: UART baudrate.
\*	   	UartWordLen: UART word length.
\* 		UartStopBits: UART stop bits.                                          
\*	   	UartParity:	UART parity.                                            
\*	   	UartFifoControl: UART FIFO control.                                       
\*	   	UartLoopway: UART loop.
\********************************************************************************/
void UART_setup(Uint32 channel,Uint16 UartBaud,Uint8 UartWordLen,
				Uint8 UartStopBits,Uint8 UartParity,Uint8 UartFifoContril,
				Uint8 UartLoopway);
/********************************************************************************\

\*UART_receive_single() -Receive serial data,and set the related registers
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		rec_data_add:Start Add for storing reveived data.
\*Return:0,Receive finished.
		 1,Data not be ready.
		 0xFFFF,serial port error.
		 2,Interrupt timeout error.
\********************************************************************************/
Uint16 UART_recive_single(Uint32 Channel);

/********************************************************************************\
\*UART_send_single()	-Send data only a time,and set the related registers.
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		send_data: Data to be sended.
\*Return: No.
\********************************************************************************/
void UART_send_single(Uint32 channel,Uint8 send_data);

/*UART_send()	-Send serial data,and set the related Registers.
\*Parameters:
\*		channel: Channel NO. UART A or UART B.
\*		length: Be sended data length.
\*		send_data_add:The start address for to be sended data.
\*Return: No.
\********************************************************************************/
void UART_send(Uint32 channel,Uint16 BaudRate,Uint16 length,Uint8 *send_data);

/********************************************************************************/
/********************************************************************************/
void UART_IntSetup(Uint32 channel,Uint8 UartIntn);

#endif	
